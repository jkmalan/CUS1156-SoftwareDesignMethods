package com.jkmalan.Lab1;

/**
 * @author jkmalan (aka John Malandrakis)
 *
 */
public class CatManagerTester {

    public static void main(String[] args) {

        CatManager catManager = new CatManager();
        System.out.println("Done!");

    }

}
